function display(CPD)

disp('softmax_CPD object');
disp(struct(CPD)); 
